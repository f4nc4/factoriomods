local smoke_animations = require("__base__.prototypes.entity.smoke-animations")
local tile_sounds = require("__mech-armor__/tile-sounds")

require("__mech-armor__.mech-armor-animations")

-- Required to load space-travel feature flag without space age
if not data.raw.tile["empty-space"] then
  local empty_space = table.deepcopy(data.raw.tile["out-of-map"])
  empty_space.name = "empty-space"
  data:extend{empty_space}
end

local factoriopedia_mech_armor_simulation =
{
  init =
  [[
    game.simulation.camera_zoom = 3.5
    game.simulation.camera_position = {0.5, -0.4}
    local character = game.surfaces[1].create_entity{name = "character", position = {0.5, 0.5}, force = "player", direction = defines.direction.south}
    character.insert{name = "mech-armor"}
  ]]
}


data:extend{
  {
    type = "technology",
    name = "mech-armor",
    icon = "__mech-armor__/graphics/technology/mech-armor.png",
    icon_size = 256,
    effects =
    {
      {
        type = "unlock-recipe",
        recipe = "mech-armor"
      },
    },
    prerequisites = {"power-armor-mk2", "fission-reactor-equipment", "efficiency-module-3", "speed-module-3"},
    unit =
    {
      count = 5000,
      ingredients =
      {
        {"automation-science-pack", 1},
        {"logistic-science-pack", 1},
        {"chemical-science-pack", 1},
        {"military-science-pack", 1},
        {"production-science-pack", 1},
        {"utility-science-pack", 1},
      },
      time = 60
    }
  },
  {
    type = "recipe",
    name = "mech-armor",
    enabled = false,
    energy_required = 60,
    ingredients =
    {
      {type = "item", name = "power-armor-mk2", amount = 1},
      {type = "item", name = "flying-robot-frame", amount = 100},
      {type = "item", name = "processing-unit", amount = 100},
      {type = "item", name = "low-density-structure", amount = 100},
      {type = "item", name = "speed-module-3", amount = 50},
      {type = "item", name = "efficiency-module-3", amount = 50},
    },
    results = {{type="item", name="mech-armor", amount=1}}
  },
  {
    type = "equipment-grid",
    name = "huge-equipment-grid",
    width = 10,
    height = 12,
    equipment_categories = {"armor"}
  },
  {
    type = "armor",
    name = "mech-armor",
    icon = "__mech-armor__/graphics/icons/mech-armor.png",
    resistances =
    {
      {
        type = "physical",
        decrease = 10,
        percent = 50
      },
      {
        type = "acid",
        decrease = 0,
        percent = 70
      },
      {
        type = "explosion",
        decrease = 60,
        percent = 50
      },
      {
        type = "fire",
        decrease = 10,
        percent = 70
      }
    },
    subgroup = "armor",
    order = "f[mech-armor]",
    factoriopedia_simulation = factoriopedia_mech_armor_simulation,
    inventory_move_sound = item_sounds.armor_large_inventory_move,
    pick_sound = item_sounds.armor_large_inventory_pickup,
    drop_sound = item_sounds.armor_large_inventory_move,
    stack_size = 1,
    infinite = true,
    equipment_grid = "huge-equipment-grid",
    inventory_size_bonus = 50,
    --character_health_bonus = 1000, -- not implemented in current version
    provides_flight = true,
    takeoff_sound = {filename = "__mech-armor__/sound/mech-armor-takeoff.ogg", volume = 0.2, aggregation = {max_count = 2, remove = true, count_already_playing = true}},
    landing_sound = {filename = "__mech-armor__/sound/mech-armor-land.ogg", volume = 0.3, aggregation = {max_count = 2, remove = true, count_already_playing = true}},
    flight_sound = {sound={filename = "__mech-armor__/sound/mech-armor-flight.ogg", volume = 0.2}},
    steps_sound = sound_variations("__mech-armor__/sound/mech-armor-steps-metallic", 5, 0.2),
    moving_sound = sound_variations("__mech-armor__/sound/mech-armor-moves", 10, 0.4),
    collision_box = {{-0.25, -0.25}, {0.25, 0.25}},
    drawing_box = {{-0.4, -2}, {0.4, 0}},
    open_sound = {filename =  "__base__/sound/armor-open.ogg", volume = 1},
    close_sound = {filename = "__base__/sound/armor-close.ogg", volume = 1},
    weight = 1*tons
  },
  smoke_animations.trivial_smoke
  {
    name = "mech-armor-smoke",
    color = {r = 0.5, g = 0.5, b = 0.5, a = 0.5},
    duration = 50,
    spread_duration = 50,
    fade_in_duration = 10,
    fade_away_duration = 40,
    start_scale = 0.1,
    end_scale = 0.3
  },
}

data.raw.tile["water-shallow"].landing_steps_sound = tile_sounds.landing.wet
data.raw.tile["grass-1"].landing_steps_sound = tile_sounds.landing.grass
data.raw.tile["grass-2"].landing_steps_sound = tile_sounds.landing.grass
data.raw.tile["grass-3"].landing_steps_sound = tile_sounds.landing.grass
data.raw.tile["grass-4"].landing_steps_sound = tile_sounds.landing.grass
data.raw.tile["dry-dirt"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["dirt-1"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["dirt-2"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["dirt-3"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["dirt-4"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["dirt-5"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["dirt-6"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["dirt-7"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["sand-1"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["sand-2"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["sand-3"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["red-desert-0"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["red-desert-1"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["red-desert-2"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["red-desert-3"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["nuclear-ground"].landing_steps_sound = tile_sounds.landing.sand
data.raw.tile["stone-path"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["lab-dark-1"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["lab-dark-2"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["lab-white"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["tutorial-grid"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["concrete"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["hazard-concrete-left"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["hazard-concrete-right"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["refined-concrete"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["refined-hazard-concrete-left"].landing_steps_sound = tile_sounds.landing.concrete
data.raw.tile["refined-hazard-concrete-right"].landing_steps_sound = tile_sounds.landing.concrete
